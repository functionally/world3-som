For critiques, see:

http://models.metasd.com/tag/dice/
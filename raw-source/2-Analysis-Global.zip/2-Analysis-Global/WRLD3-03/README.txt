See also:

http://models.metasd.com/tag/world3/